import unittest
from Binary_Heap import *

class MyTestCase(unittest.TestCase):
    def test_Insert(self):
        Bin = BinHeap(5)
        Bin.insert("Hello")
        Bin.insert("Taylor")
        Bin.insert("You")
        Bin.insert("Are")
        Bin.insert("Amazing")
        Bin.insert("<3")
        x = (repr(Bin))
        self.assertEqual(x, "<3 Are Amazing Taylor Hello You")

    def test_Insert2(self):
        Bin = BinHeap(5)
        Bin.insert(1)
        Bin.insert(2)
        Bin.insert(3)
        Bin.insert(4)
        Bin.insert(5)
        Bin.insert(6)
        x = (repr(Bin))
        self.assertEqual(x, "1 2 3 4 5 6")

    def test_Insert3(self):
        Bin = BinHeap(5)
        Bin.insert(10)
        Bin.insert(7)
        Bin.insert(2)
        Bin.insert(1)
        Bin.insert(6)
        Bin.insert(3)
        x = (repr(Bin))
        self.assertEqual(x, "1 2 3 10 6 7")

    def test_Delete(self):
        Bin = BinHeap(5)
        Bin.insert("Hello")
        Bin.insert("Taylor")
        Bin.insert("You")
        Bin.insert("Are")
        Bin.insert("Amazing")
        Bin.insert("<3")
        x = (repr(Bin))
        self.assertEqual(x, "<3 Are Amazing Taylor Hello You")
        Bin.deleteMin()
        x = (repr(Bin))
        self.assertEqual(x, "Are Taylor Amazing You Hello")

    def test_Delete2(self):
        Bin = BinHeap(5)
        Bin.insert(1)
        Bin.insert(2)
        Bin.insert(3)
        Bin.insert(4)
        Bin.insert(5)
        Bin.insert(6)
        x = (repr(Bin))
        self.assertEqual(x, "1 2 3 4 5 6")
        Bin.deleteMin()
        x = (repr(Bin))
        self.assertEqual(x, "2 4 3 6 5")

    def test_Delete3(self):
        Bin = BinHeap(5)
        Bin.insert(10)
        Bin.insert(7)
        Bin.insert(2)
        Bin.insert(1)
        Bin.insert(6)
        Bin.insert(3)
        x = (repr(Bin))
        self.assertEqual(x, "1 2 3 10 6 7")
        Bin.deleteMin()
        x = (repr(Bin))
        self.assertEqual(x, '2 6 3 10 7')

    def test_Delete_Ex(self):
        Bin = BinHeap(5)
        with self.assertRaises(Exception):
            Bin.deleteMin()

    def test_size(self):
        Bin = BinHeap(5)
        Bin.insert("Hello")
        Bin.insert("Taylor")
        Bin.insert("You")
        Bin.insert("Are")
        Bin.insert("Amazing")
        Bin.insert("<3")
        self.assertEqual(Bin.size(),6)

    def test_size_array(self):
            Bin = BinHeap(5)
            Bin.insert("Hello")
            Bin.insert("Taylor")
            Bin.insert("You")
            Bin.insert("Are")
            Bin.insert("Amazing")
            Bin.insert("<3")
            self.assertEqual(len(Bin.array), 10)







if __name__ == '__main__':
    unittest.main()
