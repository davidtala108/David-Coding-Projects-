import unittest
from Kevin_Bacon import *

class MyTestCase(unittest.TestCase):
    def test_Bacon1(self):
        name = "Tom Hanks"
        self.assertEqual(find_Bacon_Num(name),1)

    def test_Bacon2(self):
        name = "John Gielgud"
        self.assertEqual(find_Bacon_Num(name),3)

    def test_Bacon3(self):
        name = "Shane Zaza"
        self.assertEqual(find_Bacon_Num(name), 2)

    def test_Bacon4(self):
        name = "Merly Streep"
        self.assertEqual(find_Bacon_Num(name), 1)

    def test_Bacon5(self):
        name = "Kevin Heart"
        with self.assertRaises(ValueError):
            self.assertEqual(find_Bacon_Num(name), 1)

    def test_max(self):
        self.assertEqual(find_max_Bacon_Num(), "Kate Winslet")

    def test_actors1(self):
        name = "John Belushi"
        name2 = "Donal Sutherland"
        self.assertEqual(find_min_link(name, name2), 1)

    def test_actors2(self):
        name = "Kathleen Quinlan"
        name2 = "Donal Sutherland"
        self.assertEqual(find_min_link(name, name2), 2)

    def test_actors3(self):
        name = "Kathleen Quinlan"
        name2 = "Paul Herbert"
        self.assertEqual(find_min_link(name, name2), 2)

    def test_actors4(self):
        name = "Grace Kelly"
        name2 = "Kate Winslet"
        self.assertEqual(find_min_link(name, name2), 4)

    def test_actors5(self):
        name = "Dwayne Johnson"
        name2 = "Kate Winslet"
        with self.assertRaises(ValueError):
            self.assertEqual(find_min_link(name, name2), 3)

    def test_actors6(self):
        name = "Grace Kelly"
        name2 = "Jack Black"
        with self.assertRaises(ValueError):
            self.assertEqual(find_min_link(name, name2), 3)





if __name__ == '__main__':
    unittest.main()
